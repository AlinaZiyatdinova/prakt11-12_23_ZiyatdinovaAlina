﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace практика_11_12__задание_3_
{
    public partial class Form1 : Form
    {
        Random rnd = new Random();
        public Form1()
        {
            InitializeComponent();
            numericUpDown1.Minimum = rnd.Next(10, 101);
            numericUpDown2.Minimum = rnd.Next(10, 101);
            numericUpDown3.Minimum = rnd.Next(10, 101);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            
            Robot robot1 = new Robot();
            robot1.kollife = Convert.ToInt32(numericUpDown1.Value);
            robot1.min(robot1.kollife);
            label1.Text = "Количество жизней робота 1 в начале игры: " +Convert.ToString(robot1.kollife);
            int a = robot1.kollife;
            robot1.min(robot1.kollife);
            label2.Text = "Количество жизней робота 1 в конце игры: " + Convert.ToString(robot1.Getkollife());

            Robot robot2 = new Robot();
            robot2.kollife = Convert.ToInt32(numericUpDown2.Value);
            label6.Text = "Количество жизней робота 2 в начале игры: " + Convert.ToString(robot2.kollife);
            robot2.Lifebeforegame(a, robot1.kollife);
            label5.Text = "Количество жизней робота 2 в конце игры: " + Convert.ToString(robot2.Getkollife());

            Robot robot3 = new Robot();
            robot3.kollife = Convert.ToInt32(numericUpDown3.Value);
            label9.Text = "Количество жизней робота 3 в начале игры: " + Convert.ToString(robot3.kollife);
            robot3.Lifebeforegame(a, robot1.kollife);
            label8.Text = "Количество жизней робота 3 в конце игры: " + Convert.ToString(robot3.Getkollife());
        }
    }
}
